#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 texel = texture(Sampler0, texCoord0);
    // Blade: the disconnect label is drawn with marker glyphs (blue 254). Greyed out, as on the
    // reconfiguring screen, it is not drawn; white, as in the pause menu, it stays.
    if (texel.a > 0.0 && texel.r > 0.996 && abs(texel.b - 254.0 / 255.0) < 0.002) {
        float grey = vertexColor.r;
        if ((grey > 0.45 && grey < 0.8) || (grey > 0.1 && grey < 0.2)) {
            discard;
        }
    }
    vec4 color = texel * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
